struct _abracadabra_type {};
int _abracadabra_cast(_abracadabra_type);
#include "stdio.h"
#include "stdlib.h"
#include "random"
#include "ctime"
#include "graphics.h"
