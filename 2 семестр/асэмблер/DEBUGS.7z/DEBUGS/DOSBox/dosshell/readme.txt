=====================================================================
DOSShell v1.9   by   Loonies Software                March 21st, 2012
=====================================================================
http://www.loonies.narod.ru                           loonies@mail.ru
=====================================================================


Contents:

1. Description
2. Contact


1. Description
-----------------------------------
DOSShell is an x86 DOS applications-launcher that works in tandem
with the outstanding DOSBox emulator.  Plus, it is also a convenient
Explorer-like entries manager, where you can store links for all of
your often-used DOS programs.  Forget about typing-in boring commands
at the DOS-Prompt: All that you need to do is to add a record into
DOSShell's database, and then you can enjoy the simplicity and speed
of running your favorite old-games and software!

Before you begin using DOSShell, you might should install the latest
version of DOSBox, which can be downloaded from:

http://www.dosbox.com

Next, run the DOSShell GUI.  You can open the 'Preferences' dialog by
clicking on "Edit" -> "Preferences..." at the tool-bar menu.  Next,
you should specify the folder-path of where you have installed DOSBox
in the corresponding text-field.  Also, below that option, you should
select a virtual "Drive Letter" from the combo-box for which to mount
a game or program's directory within DOSBox.  It is best to choose a
drive letter that is not being used by a real drive in your computer,
for example, drive letter "J".  That is all that there is to the
configuration process!

Most of the items in the "Add New Entry" and "Edit Entry" dialogs are
fairly self-explanatory, but there is one item of which may not be so
obvious.  In order for you to see a "Description" that you may have
input on one of the two "... Entry" dialogs, you must select either
"View" -> "Details" on the tool-bar menu, or you must click on the
icon below the tool-bar menu, which has a tool-tip labeled "Details".
When you do so, you should see their text-entries being displayed in
the column labeled "Description"!


2. Contact
-----------------------------------
Depending upon your responses, we may improve this program.  We ask
that you send your opinions and suggestions regarding DOSShell to
the e-mail address, below, at:

E-mail: loonies@mail.ru
Website: http://www.loonies.narod.ru