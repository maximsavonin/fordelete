#ifndef TASK_H
#define TASK_H

#define NP 10

struct Point
{
   int x, y;
};

void genPoint(int, int, int, int);
void recPoint(int, int, int, int);
void save();

#endif