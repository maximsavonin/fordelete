#ifndef CONTROL_H
#define CONTROL_H

int pole(int, int, int, int, std::string, int, int&, int);
void lineColor(int, int[3][2], int, IMAGE*);
bool butSave(int, int);

#endif