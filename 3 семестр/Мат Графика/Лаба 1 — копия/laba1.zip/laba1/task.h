#ifndef TASK_H
#define TASK_H

void drawLine (int,int,int,int);
void drawStar(int,int,int,int);
void save();
#endif
