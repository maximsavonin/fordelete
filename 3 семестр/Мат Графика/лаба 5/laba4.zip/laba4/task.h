#ifndef TASK_H
#define TASK_H

void circleBre(int, int, int, int);
void fill(int, int, int[3][2]);
void save();

#endif