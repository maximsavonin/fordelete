#ifndef TASK_H
#define TASK_H

void drawCircle(int,int,int);
void drawAllCircle();
void save();
#endif
