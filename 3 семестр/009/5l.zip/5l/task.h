#ifndef TASK_H
#define TASK_H


struct Point{
   double x,y;
};

void take_dots(int,int,int,int);
void curve_bezier();
void algoritm_chaikina();
void save();

#endif