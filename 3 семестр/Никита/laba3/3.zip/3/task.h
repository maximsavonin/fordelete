#ifndef TASK_H
#define TASK_H

#define COLOR_MAX 255

struct Point
{
   int x, y;
};

void lineB(int, int, int, int);
void star(int, int, int, int);
void save();

#endif