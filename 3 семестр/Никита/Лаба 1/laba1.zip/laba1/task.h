#ifndef TASK_H
#define TASK_H

#define COLOR_MAX 255

void putp(int, int, int, int);
void fill_1(int, int, int, int, int);
void fill_2(int, int, int, int, int);
void fill_3(int, int, int, int, int);
void fill_4(int, int, int, int, int);
void fill_5(int, int, int, int, int);
void fill_6(int, int, int, int, int);
void fill_7(int, int, int, int, int);
void fill_8(int, int, int, int, int);
void save();

#endif