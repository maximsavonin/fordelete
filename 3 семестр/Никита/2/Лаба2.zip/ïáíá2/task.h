#ifndef TASK_H
#define TASK_H

struct Square
{
   int x1, y1, x2, y2;
};

void genPoint(int, int, int, int);
void recPoint(int, int, int, int);
void save();

#endif