#ifndef TASK_H
#define TASK_H

#define COLOR_MAX WHITE

void circ(int, int, int);
void circles(int, int, int);
void fill(int, int);
void save();

#endif